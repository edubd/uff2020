#P14: Binning
import pandas as pd  

#(1)-Importa a base de dados para um DataFrame
df_lojas = pd.read_csv('C:/CursoPython/lojas.csv')

#(2)-Normaliza o “salario”
dummies = pd.get_dummies(df_lojas['uf'], prefix="uf")
df_lojas = df_lojas.join(dummies)

#(4)-Projeta o nome fantasia, a uf e os novos atributos
print(df_lojas[['fantasia','uf','uf_RJ','uf_SP','uf_MG','uf_RS']])
