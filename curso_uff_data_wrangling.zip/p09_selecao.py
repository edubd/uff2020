#P09: Seleção
import pandas as pd  

#Importa a base de dados para um DataFrame
lojas = pd.read_csv('C:/CursoPython/lojas.csv')

#gera um novo DataFrame contendo apenas as lojas do RJ
v = (lojas['uf']=='RJ')
df_rj = lojas[v]

#gera um novo DataFrame contendo apenas as lojas do RJ c/ 50 ou mais funcionários
v = (lojas['uf']=='RJ') & (lojas['po']>=50)
df_rj_grandes = lojas[v]

#imprime os DataFrames
print(df_rj) 
print('-------------------------------------------')
print(df_rj_grandes) 