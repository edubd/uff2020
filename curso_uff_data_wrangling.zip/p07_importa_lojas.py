#P07: Importação de CSV padrão para DataFrame
import pandas as pd  

#Importa a base de dados para um DataFrame
lojas = pd.read_csv('C:/CursoPython/lojas.csv')
print(lojas)           
#mostra o total de linhas e colunas
print('------------------------------------')           
num_linhas = lojas.shape[0]
num_colunas = lojas.shape[1]
print("número de linhas: ", num_linhas)
print("número de colunas: ", num_colunas)    

#primeiras linhas
print('------------------------------------')           
print("primeiras linhas: ", lojas.head())

#últimas linhas
print('------------------------------------')           
print("primeiras linhas: ", lojas.tail())
