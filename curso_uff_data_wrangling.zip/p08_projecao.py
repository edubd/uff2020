#P08: Projeção
import pandas as pd  

#Importa a base de dados para um DataFrame
lojas = pd.read_csv('C:/CursoPython/lojas.csv')

#gera um novo DataFrame apenas com a uf, po e salário (nesta ordem)
lojas_proj = lojas[['uf','po','salario']]
print(lojas_proj)           
