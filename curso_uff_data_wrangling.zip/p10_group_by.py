#P10: groupby()
import pandas as pd  

#(1)-Importa a base de dados para um DataFrame
lojas = pd.read_csv('C:/CursoPython/lojas.csv')

#(2)-Gera uma variável "grouped" onde a chave é "tipo" e a medida "po"
grupo_po_uf = lojas['po'].groupby(lojas['uf'])

#(3)-Computa agregados a partir da variável gerada
print('- Soma do PO, por UF: ',grupo_po_uf.sum())
print('-----------------------------------')
print('- Total de lojas, por UF:', grupo_po_uf.count())


